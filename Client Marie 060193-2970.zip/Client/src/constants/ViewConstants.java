package constants;

public class ViewConstants {
	public static final String CalendarDay = "CalendarDay";
	public static final String Login = "Login";
	public static final String Logout = "Logout";
	public static final String CalendarProgram = "CalendarProgram";
	public static final String CreateEvent = "CreateEvent";
	
}
